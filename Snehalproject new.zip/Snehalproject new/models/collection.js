const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    phone: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    dob: { type: Date, required: true },
    gender: { type: String, enum: ['Male', 'Female', 'Non-binary'], required: true },
    occupation: { type: String },
    address: { type: String },
    created_at: { type: Date, default: Date.now },
    updated_at: { type: Date, default: Date.now },
    medicalHistory: {
        medicalConditions: [String],
        currentMedications: [String]
    }
});




const CounselingSchema = new mongoose.Schema({
    userId: { //  Store the user's ID, if you have a user authentication system
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User', // (If you have a 'User' collection)
    }, 
    
    messages: [{
      text: { type: String, required: true },
      sender: { type: String, enum: ['user', 'therapist'], required: true } // 'user' or 'therapist'
    }],
  }, { timestamps: true });

const personalExperienceSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    email: {
        type: String, 
        required: true
    },
    text: String,
    timestamp: {
        type: Date,
        default: Date.now
    }
});



const feedbackSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    rating: { type: Number, min: 1, max: 5, required: true },  // Rating from 1 to 5 stars
    feedbackText: { type: String, required: true },
    createdAt: { type: Date, default: Date.now }
});


const medicalHistorySchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    medicalConditions: [String],
    currentMedications: [String],
    therapyHistory: { type: Boolean, default: false },
    pastTherapies: [String],
    allergies: [String],
    emergencyContact: { type: String },
    additionalNotes: { type: String },
    created_at: { type: Date, default: Date.now },
    updated_at: { type: Date, default: Date.now }
});


const adminSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    privilege: { type: String, required:true,default:true},
});

const moodTrackerSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    date: { type: Date, default: Date.now },
    moodRating: { type: Number, required: true, min: 1, max: 10 },
    emotions: [{ type: String }],
    description: { type: String, maxlength: 500 }
});


const reminderSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    workout: { type: String, default: "no" },
    drinkWater: { type: String, default: "no" },
    sleepEarly: { type: String, default: "no" },
    takeWalk: { type: String, default: "no" },
    listenMusic: { type: String, default: "no" },
    extraActivity: { type: String, default: "no" },
    date: { type: String, required: true } // Store the date as a string (e.g., "YYYY-MM-DD")
});




const User = mongoose.model('User', userSchema);
const Counseling = mongoose.model('Counseling', CounselingSchema);
const PersonalExperience = mongoose.model('PersonalExperience', personalExperienceSchema);
const MedicalHistory = mongoose.model('MedicalHistory', medicalHistorySchema);
const Admin = mongoose.model('Admin', adminSchema);
const Feedback = mongoose.model('Feedback', feedbackSchema);
const MoodTracker = mongoose.model('MoodTracker', moodTrackerSchema);
const Reminder = mongoose.model('Reminder', reminderSchema);


module.exports = {
    User,
    Counseling,
    MedicalHistory,
    Admin,
    Feedback,
    PersonalExperience,
    MoodTracker,
    Reminder
};