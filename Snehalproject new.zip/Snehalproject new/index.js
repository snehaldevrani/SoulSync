const express=require('express');
const app=express();
const PORT=9000;
const path=require("path");
const db=require("./models/collection");
const{connectMongodb}=require("./connection");
app.use(express.urlencoded({extended:false}));
app.use(express.json());
app.set("view engine","ejs");
app.set('views',path.resolve("./views"));
const session=require("express-session");
const { ObjectId } = require('mongodb');
const { User, PersonalExperience } = require('./models/collection');
const MoodTracker = require('./models/collection');
app.use(express.static(path.join(__dirname, 'views')));
const Reminder = require('./models/collection');  
const currentDate = new Date().toISOString().split('T')[0]; 





app.use(session({
    secret: 'test@#$123', 
    resave: false,
    saveUninitialized: true,
    cookie: {
        maxAge: 1000 * 60 * 60 * 24 // Set cookie to expire in 24 hours
    }
}));

connectMongodb("mongodb://127.0.0.1:27017/SoulSync",{useNewUrlParser: true,
    useUnifiedTopology: true}).then(()=>console.log("mongo connected"));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


app.get('/', (req, res) => {
    res.render('home'); 
});





app.post('/signup', async (req, res) => {
    try {
        
        const existingUser = await db.User.findOne({ email: req.body.email });
        if (existingUser) {
            
            return res.redirect('/alreadyregistered');
        }

        
        const newUser = new db.User({
            name: req.body.name,
            phone: req.body.phone,
            email: req.body.email,
            password: req.body.password,  
            dob: req.body.dob,
            gender: req.body.gender
        });
        
        await newUser.save();

        req.session.userId = newUser._id;
        
        res.redirect('/dashboardpage');
    } catch (err) {
        console.error(err);
        res.redirect('/login'); 
    }
});

app.get('/alreadyregistered', (req, res) => {
    res.render('alreadyregistered'); 
});



app.get('/login', (req, res) => {
    const loginMsg = req.query.loginMsg || null;
    res.render('login', { loginMsg });
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        
        let admin = await db.Admin.findOne({ email });
        if (admin && admin.password === password) {
            req.session.isAdmin = true;
            req.session.user = { id: admin._id, email: admin.email };
            return res.redirect('/admin');
        }
        
        
        let user = await db.User.findOne({ email });
        if (user && user.password === password) {
            req.session.isAdmin = false;
            req.session.user = { id: user._id, email: user.email };
            req.session.userId = user._id; 
            return res.redirect('/dashboardpage');
        }

        
        res.render('login', { loginMsg: 'Invalid credentials, please try again.' });
    } catch (err) {
        console.error(err);
        res.render('login', { loginMsg: 'An error occurred. Please try again later.' });
    }
});

// Logout API
app.post('/logout', (req, res) => {
    if (req.session) {
      // Destroy the session
      req.session.destroy(err => {
        if (err) {
          console.error('Error destroying session:', err);
          return res.status(500).send('Logout failed.');
        }
        res.clearCookie('connect.sid'); // Clear the session cookie
        res.status(200).send('Logged out successfully.');
      });
    } else {
      res.status(400).send('No session found.');
    }
  });
  

app.get('/admin', async (req, res) => {
    if (req.session.isAdmin) {
        try {
            const users = await db.User.find();
            res.render('admin', { users });
        } catch (err) {
            console.error(err);
            res.redirect('/login');
        }
    } else {
        res.redirect('/login');
    }
});




app.get('/admin/all-users', async (req, res) => {
    if (req.session.isAdmin) {
        try {
            // Fetch all users from the database
            const users = await User.find();
            
            // Pass the users data to the EJS template
            res.render('all-users', { users, successMsg: req.query.successMsg || '', errorMsg: req.query.errorMsg || '' });
        } catch (err) {
            console.error("Error fetching users:", err);
            res.status(500).send("Server error");
        }
    } 
    else {
        res.redirect('/login');
    }
});


app.post('/admin/delete-user', async (req, res) => {
    const { userId } = req.body;  // Get the userId from the form

    try {
        // First, ensure the user is not an admin or some other superuser
        const user = await User.findById(userId);
        if (!user) {
            return res.redirect('/admin/all-users?errorMsg=User%20not%20found');
        }

        // Delete all data associated with the user from other collections (using the user's userId)
        const deletionPromises = [
            db.PersonalExperience.deleteMany({ userId }),   // Delete personal experiences
            db.Reminder.deleteMany({ userId }),              // Delete reminders
            db.MoodTracker.deleteMany({ userId }),            // Delete mood tracker entries
            db.MedicalHistory.deleteMany({ userId }),         // Delete medical histories
            db.Feedback.deleteMany({ userId })                // Delete feedback
        ];

        // Log the deletion process for transparency
        console.log(`Deleting data for userId: ${userId}`);

        await Promise.all(deletionPromises);

        // Now delete the user from the User collection
        await User.findByIdAndDelete(userId);

        // Redirect back to the all-users page with a success message
        res.redirect('/admin/all-users?successMsg=User%20deleted%20successfully');
    } catch (err) {
        console.error("Error deleting user:", err);
        // Redirect back with an error message if deletion fails
        res.redirect('/admin/all-users?errorMsg=Failed%20to%20delete%20user');
    }
});



app.get('/admin/medical-history', async (req, res) => {
    if (req.session.isAdmin) {
        try {
            const medicalHistories = await db.MedicalHistory.find().populate('userId');
            res.render('medicalHistory', { medicalHistories });
        } catch (err) {
            console.error(err);
            res.redirect('/login');
        }
    } else {
        res.redirect('/login');
    }
});

app.get('/admin/feedback-data', async (req, res) => {
    if (req.session.isAdmin) {
        try {
            const feedbacks = await db.Feedback.find().populate('userId').exec();
            res.render('feedbackData', { feedbacks, successMsg: null, errorMsg: null });
        } catch (err) {
            console.error(err);
            res.render('feedbackData', { feedbacks: [], successMsg: null, errorMsg: 'Failed to load feedback data.' });
        }
    } else {
        res.redirect('/login');
    }
});


app.get('/admin/expdata', async (req, res) => {
    try {
        // Fetch all personal experiences with the user's email
        const experiences = await PersonalExperience.find().populate('userId', 'email');

        // Render the expdata page with all experiences
        res.render('expdata', {
            experiences,
            successMsg: req.query.successMsg || '',
            errorMsg: req.query.errorMsg || ''
        });
    } catch (err) {
        console.error("Error fetching personal experiences:", err);
        res.redirect('/admin/expdata?errorMsg=Failed%20to%20fetch%20data');
    }
});

app.post('/admin/delete-expdata', async (req, res) => {
    const { experienceId } = req.body; // Get the experienceId from the form

    try {
        // Find and delete the personal experience
        await PersonalExperience.findByIdAndDelete(experienceId);

        // Redirect back to the expdata page with a success message
        res.redirect('/admin/expdata?successMsg=Comment%20deleted%20successfully');
    } catch (err) {
        console.error("Error deleting comment:", err);
        // Redirect back with an error message if deletion fails
        res.redirect('/admin/expdata?errorMsg=Failed%20to%20delete%20comment');
    }
});



app.get('/admin/mood-tracker', async (req, res) => {
    if (req.session.isAdmin) { 
        try {
            
            const moodEntries = await db.MoodTracker.find().populate('userId', 'email').sort({ date: -1 });
            res.render('mood-tracker-data', { moodEntries, errorMsg: '' }); 
        } catch (err) {
            console.error(err);
            res.render('mood-tracker-data', { moodEntries: [], errorMsg: 'Failed to load mood tracker data.' });
        }
    } else {
        res.redirect('/login'); 
    }
});

app.post('/admin/mood-tracker/delete/:id', async (req, res) => {
    if (!req.session.adminId) {
        return res.redirect('/admin/login'); 
    }

    try {
        await db.MoodTracker.findByIdAndDelete(req.params.id);
        res.redirect('/admin/mood-tracker');
    } catch (err) {
        console.error(err);
        res.redirect('/admin/mood-tracker?errorMsg=Failed+to+delete+mood+entry.');
    }
});



app.get('/admin/reminders', async (req, res) => {
    try {
        // Fetch reminders and populate user email
        const reminders = await db.Reminder.find().populate('userId', 'email').exec();

        // Group reminders by user email
        const groupedReminders = reminders.reduce((acc, reminder) => {
            const userEmail = reminder.userId.email;
            if (!acc[userEmail]) {
                acc[userEmail] = [];
            }
            acc[userEmail].push(reminder); // Add reminder entry for the user
            return acc;
        }, {});

        res.render('reminders-data', { reminders: groupedReminders });
    } catch (err) {
        console.error("Error fetching reminders:", err);
        res.redirect('/admin/reminders?errorMsg=Failed%20to%20fetch%20reminders');
    }
});


// ... your existing code ...

app.get('/mydata', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login'); 
    }
    try {
        const userId = req.session.userId;
        const moodData = await db.MoodTracker.find({ userId }).sort({ date: 1 });
        const remindersData = await db.Reminder.find({ userId }).sort({ date: 1 }); // Use the Reminder model
        res.render('mydata', { moodData, reminders: remindersData }); // Pass both moodData and reminders
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error fetching mood data' });
    }
});












app.get('/about', (req, res) => {
    res.render('aboutus'); 
});


app.get('/dashboardpage', (req, res) => {
    if (req.session.userId) {
        res.render('dashboardpage');
    } else {
        res.redirect('/login');
    }
});


app.get('/articles', (req, res) => {
    res.render('articles', { message: '' });
});


app.get('/personal-experience', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    try {
        const experiences = await PersonalExperience.find({}).sort({ timestamp: -1 }).populate('userId', 'email');

        res.render('personalExperience', {
            experiences: experiences,
            userId: req.session.userId, // Ensuring the logged-in user's ID is passed to the template
            successMsg: null,
            errorMsg: null
        });
    } catch (err) {
        console.error(err);
        res.render('personalExperience', { experiences: [], userId: req.session.userId, successMsg: null, errorMsg: 'Failed to load experiences.' });
    }
});



app.post('/personal-experience', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    const { text } = req.body;

    try {
        const user = await User.findById(req.session.userId);
        const newExperience = new PersonalExperience({
            userId: req.session.userId,
            email: user.email,  
            text: text,
            timestamp: Date.now()
        });

        await newExperience.save();
        res.redirect('/personal-experience');
    } catch (err) {
        console.error(err);
        res.render('personalExperience', { experiences: [], userId: req.session.userId, errorMsg: 'Failed to post experience.' });
    }
});


app.post('/personal-experience/delete/:id', async (req, res) => {
    try {
        const { id } = req.params;

        // Check if the experience exists
        const experience = await PersonalExperience.findById(id);
        if (!experience) {
            return res.status(404).json({ error: "Personal experience not found." });
        }


        // Delete the experience
        await PersonalExperience.findByIdAndDelete(id);

        return res.redirect('/personal-experience');
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "An error occurred while deleting the personal experience. Please try again later." });
    }
    

});



app.get('/medical-history', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    try {
        
        const user = await db.User.findById(req.session.userId).exec();
        if (!user) {
            return res.redirect('/login');
        }

        res.render('medical-history', { user });
    } catch (err) {
        console.error(err);
        res.redirect('/');
    }
});


app.get('/analysis', (req, res) => {
    
    res.render('analysis');
});



app.get('/counseling', (req, res) => {
    if (req.session.userId) { 
      // User is logged in
      db.Counseling.findOne({ userId: req.session.userId }) 
        .then(counseling => {
          if (counseling) {
            res.render('counseling', { counseling });
          } else {
            db.Counseling.create({ userId: req.session.userId })
              .then(newCounseling => {
                res.render('counseling', { counseling: newCounseling });
              })
              .catch(err => {
                console.error('Error creating counseling record:', err);
                res.status(500).send('Error creating counseling record');
              });
          }
        })
        .catch(err => {
          console.error('Error finding counseling record:', err);
          res.status(500).send('Error finding counseling record');
        });
    } else {
      // User is not logged in
      res.redirect('/login'); 
    }
  });

  app.post('/counseling', (req, res) => {
    if (req.session.userId) {
      const { message } = req.body; 
      db.Counseling.findOne({ userId: req.session.userId })
        .then(counseling => {
          if (counseling) {
            counseling.messages.push({ text: message, sender: 'user' });
            counseling.save()
              .then(() => {
                res.redirect('/counseling'); 
              })
              .catch(err => {
                console.error('Error saving message:', err);
                res.status(500).send('Error saving message');
              });
          } else {
            // (This shouldn't happen if you're handling new records on the GET route)
            res.status(404).send('Counseling record not found');
          }
        })
        .catch(err => {
          console.error('Error finding counseling record:', err);
          res.status(500).send('Error finding counseling record');
        });
    } else {
      res.redirect('/login');
    }
  });




  app.get('/admin/counselingdata', (req, res) => {
     // Check if admin is logged in
      db.Counseling.find({})
        .then(counselingData => {
          res.render('counselingdata', { counselingData });
        })
        .catch(err => {
          console.error('Error fetching counseling data:', err);
          res.status(500).send('Error fetching counseling data');
        });
     
  });



  app.post('/admin/counselingdata', (req, res) => {
    const { userId, message } = req.body; 
    db.Counseling.findOne({ userId })
      .then(counseling => {
        if (counseling) {
          counseling.messages.push({ text: message, sender: 'therapist' });
          counseling.save()
            .then(() => {
              res.redirect('/admin/counselingdata'); 
            })
            .catch(err => {
              console.error('Error saving reply:', err);
              res.status(500).send('Error saving reply');
            });
        } else {
          res.status(404).send('Counseling record not found');
        }
      })
      .catch(err => {
        console.error('Error finding counseling record:', err);
        res.status(500).send('Error finding counseling record');
      });
  });








app.get('/feedback', (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }
    res.render('feedback', { errorMsg: null });  
});

app.post('/feedback', async (req, res) => {
    const { rating, feedbackText } = req.body;

    try {
        const feedback = new db.Feedback({
            userId: req.session.userId,
            rating,
            feedbackText
        });

        await feedback.save();
        res.redirect('/dashboardpage');  
    } catch (err) {
        console.error(err);
        res.render('feedback', { errorMsg: 'Failed to submit feedback. Please try again.' });
    }
});




app.get('/reminders', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    try {
        let reminders = await db.Reminder.findOne({
            userId: req.session.userId,
            date: currentDate,
        });

        if (!reminders) {
            reminders = await db.Reminder.create({
                userId: req.session.userId,
                date: currentDate,
            });
        }

        // Calculate the number of completed tasks
        const completedTasks = Object.values(reminders.toObject())
            .filter(status => status === 'yes').length;

        // Pass both reminders and completedTasks to the template
        res.render('reminders', { reminders, completedTasks });
    } catch (err) {
        console.error("Error fetching reminders:", err);
        res.render('reminders', { reminders: null, completedTasks: 0 });
    }
});




app.post('/reminders/update', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    const { task } = req.body;
    const currentDate = new Date().toISOString().split('T')[0];

    try {
        await db.Reminder.updateOne(
            { userId: req.session.userId, date: currentDate },
            { $set: { [task]: "yes" } }
        );

        res.status(200).send({ message: "Task updated successfully." });
    } catch (err) {
        console.error("Error updating task:", err);
        res.status(500).send({ error: "Failed to update task." });
    }
});







app.get('/mood-tracker', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    try {
        // Fetch existing mood tracker entries for the logged-in user
        const moodEntries = await db.MoodTracker.find({ userId: req.session.userId }).sort({ date: -1 });
        res.render('mood-tracker', { moodEntries, errorMsg: null }); // Ensure errorMsg is defined
    } catch (err) {
        console.error(err);
        res.render('mood-tracker', { moodEntries: [], errorMsg: 'Failed to load mood tracker entries.' });
    }
});

// POST handler to submit a new mood tracker entry
app.post('/mood-tracker', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    const { moodRating, emotions, description } = req.body;

    if (!moodRating || !emotions || !description) {
        return res.redirect('/mood-tracker?errorMsg=All+fields+are+required.');
    }

    try {
        const newMoodEntry = new db.MoodTracker({
            userId: req.session.userId,
            moodRating,
            emotions: emotions.split(',').map(item => item.trim()), // Handle multiple emotions
            description
        });

        await newMoodEntry.save();
        res.redirect('/mood-tracker');
    } catch (err) {
        console.error(err);
        res.redirect('/mood-tracker?errorMsg=Failed+to+submit+mood+entry.');
    }
});


// POST handler to delete a mood tracker entry
app.post('/mood-tracker/delete/:id', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    try {
        await db.MoodTracker.findByIdAndDelete(req.params.id);
        res.redirect('/mood-tracker');
    } catch (err) {
        console.error(err);
        res.redirect('/mood-tracker?errorMsg=Failed+to+delete+mood+entry.');
    }
});




// GET /profile - Retrieve and display the user's profile
app.get('/profile', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    try {
        // Fetch the user's data
        const user = await db.User.findById(req.session.userId).lean(); // Use .lean() to get a plain object
        if (!user) {
            return res.redirect('/login');
        }

        // Fetch the user's medical history
        const medicalHistory = await db.MedicalHistory.findOne({ userId: user._id }).lean();

        // Render the profile page with user and medical history data
        res.render('profile', {
            user: user,
            medicalHistory: medicalHistory || {
                medicalConditions: [],
                currentMedications: [],
                therapyHistory: false,
                pastTherapies: [],
                allergies: [],
                emergencyContact: '',
                additionalNotes: ''
            }
        });
    } catch (err) {
        console.error(err);
        res.redirect('/login');
    }
});

// POST /profile/update - Update the user's profile
app.post('/profile/update', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    try {
        // Update the user's basic details
        await db.User.findByIdAndUpdate(req.session.userId, {
            name: req.body.name,
            email: req.body.email,
            phone: req.body.phone,
            dob: req.body.dob,
            gender: req.body.gender,
            occupation: req.body.occupation,
            address: req.body.address
        });

        // Update the user's medical history
        await db.MedicalHistory.findOneAndUpdate(
            { userId: req.session.userId },
            {
                medicalConditions: req.body.medicalConditions.split(',').map(item => item.trim()),
                currentMedications: req.body.currentMedications.split(',').map(item => item.trim()),
                therapyHistory: !!req.body.therapyHistory,
                pastTherapies: req.body.pastTherapies.split(',').map(item => item.trim()),
                allergies: req.body.allergies.split(',').map(item => item.trim()),
                emergencyContact: req.body.emergencyContact,
                additionalNotes: req.body.additionalNotes
            },
            { upsert: true, new: true }
        );

        // Redirect back to the profile page after updating
        res.redirect('/profile');
    } catch (err) {
        console.error(err);
        res.redirect('/profile');
    }
});


app.post('/profile/medical-history/update', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.redirect('/login');
        }

        const medicalHistoryData = {
            userId: req.session.userId,
            medicalConditions: req.body.medicalConditions.split(',').map(item => item.trim()),
            currentMedications: req.body.currentMedications.split(',').map(item => item.trim()),
            therapyHistory: !!req.body.therapyHistory,
            pastTherapies: req.body.pastTherapies.split(',').map(item => item.trim()),
            allergies: req.body.allergies.split(',').map(item => item.trim()),
            emergencyContact: req.body.emergencyContact,
            additionalNotes: req.body.additionalNotes
        };

        await db.MedicalHistory.findOneAndUpdate(
            { userId: req.session.userId },
            medicalHistoryData,
            { upsert: true, new: true }
        );

        res.redirect('/profile');
    } catch (err) {
        console.error(err);
        res.redirect('/profile');
    }
});



app.listen(PORT,()=>{
    console.log(`Server Running:${PORT}`);
})

